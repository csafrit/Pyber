
import csv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import seaborn as sb


```python
csv_city = "../Week-05-Matplotlib/Instructions/Pyber/raw_data/city_data.csv"
csv_ride = "../Week-05-Matplotlib/Instructions/Pyber/raw_data/ride_data.csv"

city_df = pd.read_csv(csv_city)
ride_df = pd.read_csv(csv_ride)

# Output File Names
file_output_city_csv = "generated_data/city_data.csv"
file_output_rides_csv = "generated_data/ride_data.csv"
```


```python
city_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
city_count = len(city_df["city"])
city_count
#There are 126 cities
```




    126




```python
ride_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
    </tr>
  </tbody>
</table>
</div>




```python
num_rides = len(ride_df["ride_id"])
num_rides
#There are 2375 rides
```




    2375




```python
#Check information from df
drivers = city_df["driver_count"].sum()
drivers
```




    3349




```python
avg_fare = ride_df["fare"].mean()
avg_fare
```




    26.80055157894731




```python
ride_type = city_df.groupby(["type"])
ride_type.describe()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="8" halign="left">driver_count</th>
    </tr>
    <tr>
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
    <tr>
      <th>type</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Rural</th>
      <td>18.0</td>
      <td>5.777778</td>
      <td>2.579456</td>
      <td>3.0</td>
      <td>3.00</td>
      <td>6.0</td>
      <td>7.75</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>Suburban</th>
      <td>42.0</td>
      <td>15.190476</td>
      <td>7.651680</td>
      <td>1.0</td>
      <td>9.00</td>
      <td>16.0</td>
      <td>21.00</td>
      <td>27.0</td>
    </tr>
    <tr>
      <th>Urban</th>
      <td>66.0</td>
      <td>39.500000</td>
      <td>21.726446</td>
      <td>4.0</td>
      <td>20.25</td>
      <td>43.0</td>
      <td>59.50</td>
      <td>73.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Driver by city type calcs
driver_rural = sum(city_df["driver_count"].loc[city_df["type"] == "Rural"])
driver_rural
```




    104




```python
driver_suburban = sum(city_df["driver_count"].loc[city_df["type"] == "Suburban"])
driver_suburban
```




    638




```python
driver_urban = sum(city_df["driver_count"].loc[city_df["type"] == "Urban"])
driver_urban
```




    2607




```python
#Add driver count to ride_df
driver_counts = city_df.set_index('city')['driver_count'].to_dict()
driver_counts
```




    {'Alvarezhaven': 21,
     'Alyssaberg': 67,
     'Anitamouth': 16,
     'Antoniomouth': 21,
     'Aprilchester': 49,
     'Arnoldview': 41,
     'Campbellport': 26,
     'Carrollbury': 4,
     'Carrollfort': 55,
     'Clarkstad': 21,
     'Conwaymouth': 18,
     'Davidtown': 73,
     'Davistown': 25,
     'East Cherylfurt': 9,
     'East Douglas': 12,
     'East Erin': 43,
     'East Jenniferchester': 22,
     'East Leslie': 9,
     'East Stephen': 6,
     'East Troybury': 3,
     'Edwardsbury': 11,
     'Erikport': 3,
     'Eriktown': 15,
     'Floresberg': 7,
     'Fosterside': 69,
     'Hernandezshire': 10,
     'Horneland': 8,
     'Jacksonfort': 6,
     'Jacobfort': 52,
     'Jasonfort': 25,
     'Jeffreyton': 8,
     'Johnland': 13,
     'Kellershire': 51,
     'Kelseyland': 63,
     'Kennethburgh': 3,
     'Kimberlychester': 13,
     'Kinghaven': 3,
     'Kyleton': 12,
     'Lake Brenda': 24,
     'Lake Jeffreyland': 15,
     'Lake Jennaton': 65,
     'Lake Sarashire': 8,
     'Lake Stevenbury': 63,
     'Lisatown': 47,
     'Lisaville': 66,
     'Manuelchester': 7,
     'Martinmouth': 5,
     'Maryside': 20,
     'Matthewside': 4,
     'Mooreview': 34,
     'New Aaron': 60,
     'New Andreamouth': 42,
     'New Brandonborough': 9,
     'New Christine': 22,
     'New Cindyborough': 20,
     'New David': 31,
     'New Jeffrey': 58,
     'New Jessicamouth': 22,
     'New Johnbury': 6,
     'New Lynn': 20,
     'New Maryport': 26,
     'New Michelleberg': 9,
     'New Samanthaside': 16,
     'Nguyenbury': 8,
     'North Tara': 14,
     'North Tracyfort': 18,
     'North Whitney': 10,
     'Pamelahaven': 30,
     'Paulfort': 13,
     'Pearsonberg': 43,
     'Port Alexandria': 27,
     'Port Guytown': 26,
     'Port James': 3,
     'Port Johnstad': 22,
     'Port Jose': 11,
     'Port Josephfurt': 28,
     'Port Martinberg': 44,
     'Port Michelleview': 16,
     'Port Samantha': 55,
     'Prattfurt': 43,
     'Rodriguezburgh': 52,
     'Rodriguezview': 10,
     'Russellport': 9,
     'Sandymouth': 11,
     'Sarabury': 46,
     'Sarahview': 18,
     'Shelbyhaven': 9,
     'Smithhaven': 67,
     'South Bryanstad': 73,
     'South Elizabethmouth': 3,
     'South Gracechester': 19,
     'South Jennifer': 6,
     'South Joseph': 3,
     'South Josephville': 4,
     'South Louis': 12,
     'South Roy': 35,
     'South Shannonborough': 9,
     'Spencertown': 68,
     'Stevensport': 6,
     'Stewartview': 49,
     'Swansonbury': 64,
     'Thomastown': 1,
     'Tiffanyton': 21,
     'Torresshire': 70,
     'Travisville': 37,
     'Vickimouth': 13,
     'Webstertown': 26,
     'West Alexis': 47,
     'West Brandy': 12,
     'West Brittanyton': 9,
     'West Dawnfurt': 34,
     'West Evan': 4,
     'West Jefferyfurt': 65,
     'West Kevintown': 5,
     'West Oscar': 11,
     'West Pamelaborough': 27,
     'West Paulport': 5,
     'West Peter': 61,
     'West Sydneyhaven': 70,
     'West Tony': 17,
     'Williamchester': 26,
     'Williamshire': 70,
     'Wiseborough': 55,
     'Yolandafurt': 7,
     'Zimmermanmouth': 45}




```python
driver_df1 = ride_df['city'].map(driver_counts)
driver_df1.head()
```




    0    46
    1    35
    2    55
    3    68
    4     8
    Name: city, dtype: int64




```python
#Add city type to ride_df
city_type = city_df.set_index('city')['type'].to_dict()
city_type
```




    {'Alvarezhaven': 'Urban',
     'Alyssaberg': 'Urban',
     'Anitamouth': 'Suburban',
     'Antoniomouth': 'Urban',
     'Aprilchester': 'Urban',
     'Arnoldview': 'Urban',
     'Campbellport': 'Suburban',
     'Carrollbury': 'Suburban',
     'Carrollfort': 'Urban',
     'Clarkstad': 'Suburban',
     'Conwaymouth': 'Suburban',
     'Davidtown': 'Urban',
     'Davistown': 'Urban',
     'East Cherylfurt': 'Suburban',
     'East Douglas': 'Urban',
     'East Erin': 'Urban',
     'East Jenniferchester': 'Suburban',
     'East Leslie': 'Rural',
     'East Stephen': 'Rural',
     'East Troybury': 'Rural',
     'Edwardsbury': 'Urban',
     'Erikport': 'Rural',
     'Eriktown': 'Urban',
     'Floresberg': 'Suburban',
     'Fosterside': 'Urban',
     'Hernandezshire': 'Rural',
     'Horneland': 'Rural',
     'Jacksonfort': 'Rural',
     'Jacobfort': 'Urban',
     'Jasonfort': 'Suburban',
     'Jeffreyton': 'Suburban',
     'Johnland': 'Suburban',
     'Kellershire': 'Urban',
     'Kelseyland': 'Urban',
     'Kennethburgh': 'Rural',
     'Kimberlychester': 'Urban',
     'Kinghaven': 'Rural',
     'Kyleton': 'Suburban',
     'Lake Brenda': 'Suburban',
     'Lake Jeffreyland': 'Urban',
     'Lake Jennaton': 'Urban',
     'Lake Sarashire': 'Urban',
     'Lake Stevenbury': 'Urban',
     'Lisatown': 'Urban',
     'Lisaville': 'Urban',
     'Manuelchester': 'Rural',
     'Martinmouth': 'Suburban',
     'Maryside': 'Urban',
     'Matthewside': 'Rural',
     'Mooreview': 'Urban',
     'New Aaron': 'Urban',
     'New Andreamouth': 'Urban',
     'New Brandonborough': 'Suburban',
     'New Christine': 'Urban',
     'New Cindyborough': 'Suburban',
     'New David': 'Urban',
     'New Jeffrey': 'Urban',
     'New Jessicamouth': 'Suburban',
     'New Johnbury': 'Rural',
     'New Lynn': 'Suburban',
     'New Maryport': 'Urban',
     'New Michelleberg': 'Suburban',
     'New Samanthaside': 'Suburban',
     'Nguyenbury': 'Urban',
     'North Tara': 'Suburban',
     'North Tracyfort': 'Suburban',
     'North Whitney': 'Rural',
     'Pamelahaven': 'Urban',
     'Paulfort': 'Suburban',
     'Pearsonberg': 'Urban',
     'Port Alexandria': 'Suburban',
     'Port Guytown': 'Suburban',
     'Port James': 'Suburban',
     'Port Johnstad': 'Urban',
     'Port Jose': 'Suburban',
     'Port Josephfurt': 'Urban',
     'Port Martinberg': 'Urban',
     'Port Michelleview': 'Suburban',
     'Port Samantha': 'Urban',
     'Prattfurt': 'Urban',
     'Rodriguezburgh': 'Urban',
     'Rodriguezview': 'Suburban',
     'Russellport': 'Urban',
     'Sandymouth': 'Urban',
     'Sarabury': 'Urban',
     'Sarahview': 'Suburban',
     'Shelbyhaven': 'Rural',
     'Smithhaven': 'Urban',
     'South Bryanstad': 'Urban',
     'South Elizabethmouth': 'Rural',
     'South Gracechester': 'Suburban',
     'South Jennifer': 'Suburban',
     'South Joseph': 'Rural',
     'South Josephville': 'Urban',
     'South Louis': 'Urban',
     'South Roy': 'Urban',
     'South Shannonborough': 'Suburban',
     'Spencertown': 'Urban',
     'Stevensport': 'Rural',
     'Stewartview': 'Urban',
     'Swansonbury': 'Urban',
     'Thomastown': 'Suburban',
     'Tiffanyton': 'Suburban',
     'Torresshire': 'Urban',
     'Travisville': 'Urban',
     'Vickimouth': 'Urban',
     'Webstertown': 'Suburban',
     'West Alexis': 'Urban',
     'West Brandy': 'Urban',
     'West Brittanyton': 'Urban',
     'West Dawnfurt': 'Urban',
     'West Evan': 'Suburban',
     'West Jefferyfurt': 'Urban',
     'West Kevintown': 'Rural',
     'West Oscar': 'Urban',
     'West Pamelaborough': 'Suburban',
     'West Paulport': 'Suburban',
     'West Peter': 'Urban',
     'West Sydneyhaven': 'Urban',
     'West Tony': 'Suburban',
     'Williamchester': 'Suburban',
     'Williamshire': 'Urban',
     'Wiseborough': 'Urban',
     'Yolandafurt': 'Urban',
     'Zimmermanmouth': 'Urban'}




```python
ride_df1 = ride_df['city'].map(city_type)
ride_df1.head()
```




    0    Urban
    1    Urban
    2    Urban
    3    Urban
    4    Urban
    Name: city, dtype: object




```python
city2 = ride_df["city"]
fare = ride_df["fare"]
ride = ride_df["ride_id"]

df_rides = pd.DataFrame({"City": city2,
                           "Fare": fare,
                             "Type":ride_df1,
                             "Driver_Count":driver_df1,
                             "Ride_id": ride},
                           columns = ["City", "Fare", "Type", "Driver_Count", "Ride_id"])
df_rides.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Fare</th>
      <th>Type</th>
      <th>Driver_Count</th>
      <th>Ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>38.35</td>
      <td>Urban</td>
      <td>46</td>
      <td>5403689035038</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>17.49</td>
      <td>Urban</td>
      <td>35</td>
      <td>4036272335942</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>44.18</td>
      <td>Urban</td>
      <td>55</td>
      <td>3645042422587</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>6.87</td>
      <td>Urban</td>
      <td>68</td>
      <td>2242596575892</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>6.28</td>
      <td>Urban</td>
      <td>8</td>
      <td>1543057793673</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Ride number calcs
fare_rural = len(df_rides["Ride_id"].loc[df_rides["Type"] == "Rural"])
fare_rural
```




    125




```python
fare_suburban = len(df_rides["Ride_id"].loc[df_rides["Type"] == "Suburban"])
fare_suburban
```




    625




```python
fare_urban = len(df_rides["Ride_id"].loc[df_rides["Type"] == "Urban"])
fare_urban
```




    1625




```python
#Easier method for fare calcs
#This is avg fare cost per city type, not total fares per city type. Important distinction
group_type = df_rides.groupby(["Type"])
group_type.mean()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Fare</th>
      <th>Ride_id</th>
    </tr>
    <tr>
      <th>Type</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Rural</th>
      <td>34.040720</td>
      <td>5.269835e+12</td>
    </tr>
    <tr>
      <th>Suburban</th>
      <td>30.908608</td>
      <td>4.810247e+12</td>
    </tr>
    <tr>
      <th>Urban</th>
      <td>24.663594</td>
      <td>4.855504e+12</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Calc total fare per city type
rural_tot_fares = fare_rural * 34.04
rural_tot_fares
```




    4255.0




```python
suburban_tot_fares = fare_suburban * 30.91
suburban_tot_fares
```




    19318.75




```python
urban_tot_fares = fare_urban * 24.66
urban_tot_fares
```




    40072.5




```python
# Pie Chart % of Total Fares by City Type
#this is fare cost by city type. Not total value of fares by city type
labels = ["Rural", "Suburban", "Urban"]
sizes = [4255, 19318.75, 40072.5]
colors = ["Gold", "lightcoral", "lightskyblue"]
explode = (0, 0, 0.1)

plt.pie(sizes, explode=explode, labels=labels, colors=colors,
        autopct="%1.1f%%", shadow=True, startangle=140)

plt.axis("equal")
plt.title("% of Total Fares by City Type")
plt.show()
```


![png](output_24_0.png)



```python
#Pie Chart % of Total Rides by City Type

labels = ["Rural", "Suburban", "Urban"]
sizes = [125, 625, 1625]
colors = ["Gold", "lightcoral", "lightskyblue"]
explode = (0, 0, 0.1)

plt.pie(sizes, explode=explode, labels=labels, colors=colors,
        autopct="%1.1f%%", shadow=True, startangle=140)

plt.axis("equal")
plt.title("% of Total Rides by City Type")
plt.show()
```


![png](output_25_0.png)



```python
#Pie Chart  % of Total Drivers by City Type
#Drivers
labels = ["Rural", "Suburban", "Urban"]
sizes = [104, 638, 2607]
colors = ["Gold", "lightcoral", "lightskyblue"]
explode = (0, 0, 0.1)

plt.pie(sizes, explode=explode, labels=labels, colors=colors,
        autopct="%1.1f%%", shadow=True, startangle=140)

plt.axis("equal")
plt.title("% of Total Drivers by City Type")
plt.show()
```


![png](output_26_0.png)



```python

```




    26.80055157894731




```python
data = [random.random() for value in x_axis]
data1 = [random.random() for value in y_axis] 
plt.scatter(x_axis, data, marker="o", facecolors="red", edgecolors="black",
            s=x_axis, alpha=0.75)
```


```python
#Bubble plot 
    #* Average Fare ($) Per City
    #* Total Number of Rides Per City
    #* Total Number of Drivers Per City
    #* City Type (Urban, Suburban, Rural)
    #Rainbow fish on crack #blessed 

#avg_fare = df_pyber1["fare"].mean()
#total_drivers = df_pyber1["Driver_count"]
#total_rides = (df_pyber1["Ride_id"])/100000000000

    
N=125
city = city_df["city"]
fare = ride_df["fare"]
#drivers = city_df["driver_count"]
rides = (ride_df["ride_id"])/100000000000
city_type = [125, 625, 1625]

# Choose some random colors
colors=cm.rainbow(np.random.rand(N))

# Use those colors as the color argument
plt.scatter(rides,fare,s=city_type,color=colors)
for i in range(N):
    plt.annotate(city[i],xy=(rides[i],fare[i]))
plt.xlabel('Total Rides')
plt.ylabel('Fare Average')

# Move title up with the "y" option
plt.title('Fares by City Type')
plt.show()
```


![png](output_29_0.png)

